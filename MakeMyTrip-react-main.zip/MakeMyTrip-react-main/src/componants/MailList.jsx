import React from 'react'

const MailList = () => {
    return (
        <div className="mail">
            <div className="mailTitle">
                <h1> Save time, save money! </h1>
            </div>
            <span className="mailDesc">Sign up and we'll send the best deals to you
            </span>
            <div className="mailInputContainer">
                <input type="text" className="" placeholder="Your mail"></input>
                <button> Subscribe </button>
            </div>
        </div>
    )
}

export default MailList
